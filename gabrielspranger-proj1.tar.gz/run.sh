#!/bin/bash
exec ./cachesim "$@"
